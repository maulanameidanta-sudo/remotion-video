import {Config} from '@remotion/cli/config';

Config.setVideoImageFormat('jpeg');
Config.setJpegQuality(92);
Config.setCodec('h264');
Config.setOverwriteOutput(true);
Config.setPixelFormat('yuv420p');
